//
//  ViewController.swift
//  Calculator
//
//  Created by hasna benzekri on 7/17/16.
//  Copyright © 2016 hasna benzekri. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
 
   
    @IBOutlet private weak var display: UILabel!
    private var UserIsInTheMiddleOfTyping = false
    
    @IBAction private func touchDigit(sender: UIButton){
        
        let digit = sender.currentTitle!
        
        if UserIsInTheMiddleOfTyping {
        let textCurrentInDisplay = display.text!
        display.text = textCurrentInDisplay + digit
        } else {
            display.text = digit
        }
        
       UserIsInTheMiddleOfTyping = true
        
    }
    
    private var displayValue : Double {
        get {
            return Double(display.text!)!
        }
        set{
            display.text = String(newValue)
        }
    }
    
    private var brain = CalculatorBrain()
    @IBAction private func performOperation(sender: UIButton) {
        if UserIsInTheMiddleOfTyping{
            brain.setOperand(displayValue)
        }
        UserIsInTheMiddleOfTyping = false
        if let mathematicalSymbol = sender.currentTitle{
            brain.performOperation(mathematicalSymbol)
        }
                displayValue = brain.result
            

        }
        
        
    }
    
    
   


